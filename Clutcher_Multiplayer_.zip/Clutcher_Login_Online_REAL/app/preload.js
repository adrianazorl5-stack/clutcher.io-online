const {contextBridge, ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('launcher',{
 openGame:(server)=>ipcRenderer.send('open-game',server),
 devtools:()=>ipcRenderer.send('open-devtools')
});
contextBridge.exposeInMainWorld('clOnline',{
 request:(url,method,body)=>ipcRenderer.invoke('cl-http',{url,method,body})
});
