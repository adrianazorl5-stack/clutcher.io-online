@echo off
cd /d "%~dp0app"
if not exist node_modules\electron-builder (call npm install)
npx electron-builder --win portable
pause
